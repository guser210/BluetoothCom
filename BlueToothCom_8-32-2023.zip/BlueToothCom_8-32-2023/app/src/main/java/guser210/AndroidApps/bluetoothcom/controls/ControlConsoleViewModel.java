package guser210.AndroidApps.bluetoothcom.controls;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;

public class ControlConsoleViewModel extends AndroidViewModel {
    public ControlConsoleViewModel(@NonNull Application application) {
        super(application);
    }
    // TODO: Implement the ViewModel
}