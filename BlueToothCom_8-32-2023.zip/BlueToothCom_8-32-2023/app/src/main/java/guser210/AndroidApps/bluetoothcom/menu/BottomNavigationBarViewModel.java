package guser210.AndroidApps.bluetoothcom.menu;

import androidx.lifecycle.ViewModel;

public class BottomNavigationBarViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}