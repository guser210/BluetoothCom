package guser210.AndroidApps.bluetoothcom.controls;

import androidx.lifecycle.ViewModel;

public class ControlOdometerV2ViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}