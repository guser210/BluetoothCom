package guser210.AndroidApps.bluetoothcom.menu;

import androidx.lifecycle.ViewModel;

public class ProfileSettingsMenuViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}