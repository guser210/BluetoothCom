package guser210.AndroidApps.bluetoothcom.controls;

import guser210.AndroidApps.bluetoothcom.data.BlueControlProperty;

import java.util.List;

public interface ControlPropertiesInterface {
    void onDelete();
    void onCancel();

    void onOk(List<BlueControlProperty> listOfProperties);
}


