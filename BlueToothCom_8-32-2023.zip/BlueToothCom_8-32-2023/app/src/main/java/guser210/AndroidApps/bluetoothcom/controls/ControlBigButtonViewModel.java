package guser210.AndroidApps.bluetoothcom.controls;

import androidx.lifecycle.ViewModel;

public class ControlBigButtonViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}