package guser210.AndroidApps.bluetoothcom;

import androidx.lifecycle.ViewModel;

public class ToolDropdownViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}