package guser210.AndroidApps.bluetoothcom.controls;

public interface ControlEventInterface {
    public void controlDataToDevice(String command);
    public void onDelete(ControlComm control);
}
