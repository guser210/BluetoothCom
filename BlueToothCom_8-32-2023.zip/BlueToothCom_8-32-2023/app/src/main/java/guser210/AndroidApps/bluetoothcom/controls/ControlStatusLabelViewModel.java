package guser210.AndroidApps.bluetoothcom.controls;

import androidx.lifecycle.ViewModel;

public class ControlStatusLabelViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}