package guser210.AndroidApps.bluetoothcom.menu;

import androidx.lifecycle.ViewModel;

public class PropertiesMenuViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}